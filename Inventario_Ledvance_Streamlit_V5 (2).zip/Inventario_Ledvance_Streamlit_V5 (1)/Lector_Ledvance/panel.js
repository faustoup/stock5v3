"use strict";
const root="https://tienda.ledvance.mx", $=x=>document.getElementById(x), sleep=ms=>new Promise(r=>setTimeout(r,ms));
let parar=false,blobUrl;
$("modo").onchange=async()=>{$("lista").value=$("modo").selectedIndex?(await(await fetch(chrome.runtime.getURL("sku_vigentes.txt"))).text()).trim():"83960\n83961\n88870\n88871"};
$("stop").onclick=()=>{parar=true};
async function inTab(id,func,args=[]){
 const results=await chrome.scripting.executeScript({target:{tabId:id},func,args});
 return results[0]?.result;
}
async function loaded(id,url){
 await chrome.tabs.update(id,{url});
 for(let i=0;i<150;i++){let t=await chrome.tabs.get(id);if(t.status==="complete"&&t.url===url)return; await sleep(200)}
 throw Error("La tienda no abrió la página solicitada. Comprueba tu sesión y vuelve a intentar.");
}
async function account(){
 try{const r=await fetch("/account",{credentials:"same-origin",cache:"no-store",signal:AbortSignal.timeout(15000)});
 if(!r.ok||new URL(r.url).origin!==location.origin)return false;
 const d=new DOMParser().parseFromString(await r.text(),"text/html");
 return !!d.querySelector('a[href*="/logout"],a[href*="/sign_out"],form[action*="/logout"]');
 }catch{return false}
}
async function catalog(page){
 const r=await fetch("/products.json?limit=250&page="+page,{credentials:"same-origin",signal:AbortSignal.timeout(20000)});
 if(!r.ok)return {error:r.status};
 const ps=(await r.json()).products;
 return {n:ps.length, items:ps.flatMap(p=>p.variants.filter(v=>v.sku).map(v=>[String(v.sku).trim(),p.handle,String(v.id)]))};
}
function read(sku,h,vid){
 const visible=e=>e&&e.getClientRects().length&&getComputedStyle(e).visibility!=="hidden";
 const norm=x=>(x||"").trim().replace(/\s+/g," ");
 const forms=[...document.querySelectorAll("[data-product-form][data-product]")].filter(e=>{try{return visible(e)&&JSON.parse(e.dataset.product).handle===h}catch{return false}});
 if(forms.length!==1)return null;
 const f=forms[0],el=f.querySelector("[name=id]"),v=JSON.parse(f.dataset.product).variants.find(v=>String(v.id)===vid);
 if(!el||String(el.value)!==vid||!v||String(v.sku).trim()!==sku)return null;
 const heads=[...(f.closest(".product__information")?.querySelectorAll(".sku")||[])].filter(visible);
 if(heads.length!==1||norm(heads[0].innerText)!==sku)return null;
 const lines=[...f.querySelectorAll(".variants-meta .var-item")].filter(visible);
 if(lines.length!==1||norm(lines[0].dataset.meta)!==norm(v.title))return null;
 const numbers=[...lines[0].querySelectorAll(".meta-thresold")].filter(visible);
 if(numbers.length!==1)return null;
 const m=/^(\d{1,3}(?:,\d{3})+|\d+)\s+(?:pieza\(s\)|piezas?|artículos?)\s+queda(?:n)?$/i.exec(norm(numbers[0].innerText));
 return m?Number(m[1].replaceAll(",","")):null;
}
async function valid(id){
 if(!await inTab(id,account))throw Error("No se pudo confirmar la sesión en Ledvance. Inicia sesión en el enlace del paso 1 y vuelve a consultar.");
}
$("run").onclick=async()=>{
 const skus=[...new Set($("lista").value.split(/\s+/).filter(Boolean))];
 if(!skus.length||skus.some(s=>!/^\d+$/.test(s))){$("estado").textContent="Escribe solo los SKU numéricos, uno por línea.";return}
 let id;parar=false;$("run").disabled=$("modo").disabled=$("lista").disabled=true;$("stop").disabled=false;$("descarga").hidden=true;
 try{
 $("estado").textContent="Comprobando la sesión en Ledvance…";
 id=(await chrome.tabs.create({url:"about:blank",active:false})).id;
 await loaded(id,root+"/");await valid(id);
 const idx=new Map(),seen=new Set();
 for(let pg=1;pg<=100;pg++){
   const data=await inTab(id,catalog,[pg]);if(!data||data.error)throw Error("No se pudo leer el catálogo de Ledvance.");
   const sig=JSON.stringify(data.items);if(seen.has(sig))throw Error("Catálogo incompleto: la tienda repitió una página.");seen.add(sig);
   for(const [s,h,v] of data.items){if(!idx.has(s))idx.set(s,new Map());idx.get(s).set(h+":"+v,[h,v])}
   if(data.n<250)break;if(pg===100)throw Error("Catálogo incompleto");
 }
 const rows=[],miss=[];
 for(let i=0;i<skus.length;i++){
   if(parar)throw Error("Consulta detenida. No se generó un archivo parcial.");
   const s=skus[i],opts=idx.get(s);let q=null;
   $("estado").textContent=(i+1)+"/"+skus.length+" · SKU "+s;
   if(i&&i%12===0)await valid(id);
   if(opts?.size===1){
    const [h,v]=[...opts.values()][0];await loaded(id,root+"/products/"+encodeURIComponent(h)+"?variant="+v);
    let prev=null;
    for(let k=0;k<12;k++){const val=await inTab(id,read,[s,h,v]);if(val!=null&&val===prev){q=val;break}prev=val;await sleep(350)}
   }
   if(q===null)miss.push(s);
   rows.push(s+","+(q===null?"":q));
 }
 if(parar)throw Error("Consulta detenida.");
 await valid(id);
 if(blobUrl)URL.revokeObjectURL(blobUrl);
 blobUrl=URL.createObjectURL(new Blob(["\uFEFFSKU,Cantidad\r\n"+rows.join("\r\n")+"\r\n"],{type:"text/csv;charset=utf-8"}));
 const a=$("descarga");a.href=blobUrl;a.download="Ledvance_Inventario_"+new Date().toISOString().slice(0,10)+".csv";a.hidden=false;
 $("estado").textContent=(rows.length-miss.length)+" de "+rows.length+" con cantidad verificada."+(miss.length?"\nSin confirmar (en blanco): "+miss.join(", "):"");
 }catch(e){$("estado").textContent=e.message||String(e)}
 finally{if(id)await chrome.tabs.remove(id).catch(()=>{});$("run").disabled=$("modo").disabled=$("lista").disabled=false;$("stop").disabled=true}
};
